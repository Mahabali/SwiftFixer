#!/usr/bin/env python3
"""
swift_fix.py — diff-scoped Swift formatting & lint-fixing pipeline.

Usage:
    python3 swift_fix.py <repo>  [options]

<repo> may be either:
    • a local path to a git checkout            (e.g. ~/code/MyApp)
    • a clone URL                               (e.g. https://… or git@…:org/repo.git)
      → cloned into a temp dir, operated on there.

Order of operations (as requested):
  1. SwiftFormat  --fix    (owns all spacing / line-break / blank-line rules)
  2. swiftlint    --fix    (auto-correctable lint rules)
  3. custom fixers         (a SMALL set of safe mechanical rewrites, applied
                            only on the exact lines SwiftLint flags)
  4. report                (everything left that a human must fix)

Only files that appear in `git diff` are touched. Reporting is scoped to the
changed line ranges so you don't get blamed for pre-existing violations.

Requires: SwiftFormat + SwiftLint installed, a git repo, Python 3.9+.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Callable, Dict, List, Optional, Set

# ====================== USER CONFIG — EDIT HERE ====================== #
# Tool binaries. A bare name ("swiftlint") is resolved on $PATH; an
# absolute path is used as-is. Homebrew installs to /opt/homebrew/bin
# on Apple Silicon and /usr/local/bin on Intel Macs.
SWIFTLINT_BIN   = "swiftlint"            # e.g. "/opt/homebrew/bin/swiftlint"
SWIFTFORMAT_BIN = "swiftformat"          # e.g. "/opt/homebrew/bin/swiftformat"

# Rules / config files. Leave "" to auto-discover (.swiftlint.yml and
# .swiftformat) inside the target repo (or --config-dir). Set an absolute
# path to force a specific rules file regardless of the repo's contents.
SWIFTLINT_CONFIG   = ""                  # e.g. "/Users/me/ci/.swiftlint.yml"
SWIFTFORMAT_CONFIG = ""                  # e.g. "/Users/me/ci/.swiftformat"
# ==================================================================== #


# --------------------------------------------------------------------------- #
# console helpers
# --------------------------------------------------------------------------- #
def _c(code: str, s: str) -> str:
    return f"\033[{code}m{s}\033[0m" if sys.stdout.isatty() else s

def info(s: str) -> None: print(_c("36", "» ") + s)
def ok(s: str) -> None:   print(_c("32", "✓ ") + s)
def warn(s: str) -> None: print(_c("33", "! ") + s)
def err(s: str) -> None:  print(_c("31", "✗ ") + s, file=sys.stderr)


# --------------------------------------------------------------------------- #
# subprocess wrapper
# --------------------------------------------------------------------------- #
def run(cmd: List[str], cwd: Optional[Path] = None,
        env: Optional[dict] = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd, cwd=str(cwd) if cwd else None, env=env,
        capture_output=True, text=True,
    )


# --------------------------------------------------------------------------- #
# repo preparation (local path OR clone URL)
# --------------------------------------------------------------------------- #
_URL_RE = re.compile(r"^(https?://|git@|ssh://|git://)")

def prepare_repo(repo_arg: str, branch: Optional[str]) -> "tuple[Path, bool]":
    """Returns (repo_root, was_cloned)."""
    if _URL_RE.match(repo_arg):
        tmp = Path(tempfile.mkdtemp(prefix="swiftfix_"))
        info(f"Cloning {repo_arg} → {tmp}")
        cmd = ["git", "clone", "--quiet"]
        if branch:
            cmd += ["--branch", branch]
        cmd += [repo_arg, str(tmp)]
        res = run(cmd)
        if res.returncode != 0:
            err(f"git clone failed: {res.stderr.strip()}")
            sys.exit(2)
        return tmp, True

    p = Path(repo_arg).expanduser().resolve()
    if not p.exists():
        err(f"Path does not exist: {p}")
        sys.exit(2)
    res = run(["git", "rev-parse", "--show-toplevel"], cwd=p)
    if res.returncode != 0:
        err(f"Not a git repository: {p}")
        sys.exit(2)
    if branch:
        co = run(["git", "checkout", branch], cwd=p)
        if co.returncode != 0:
            warn(f"Could not checkout '{branch}': {co.stderr.strip()}")
    return Path(res.stdout.strip()), False


# --------------------------------------------------------------------------- #
# git discovery
# --------------------------------------------------------------------------- #
def _scope_args(mode: str, base: str) -> List[str]:
    if mode == "staged":
        return ["--cached"]
    if mode == "branch":
        return [f"{base}...HEAD"]
    return ["HEAD"]  # 'working': staged + unstaged vs HEAD


def changed_swift_files(root: Path, mode: str, base: str) -> List[str]:
    cmd = ["git", "diff", "--name-only", "--diff-filter=ACMR", *_scope_args(mode, base)]
    res = run(cmd, cwd=root)
    if res.returncode != 0:
        err(f"git diff failed: {res.stderr.strip()}")
        sys.exit(2)
    return [rel for rel in res.stdout.splitlines()
            if rel.endswith(".swift") and (root / rel).is_file()]


_HUNK = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@")

def changed_line_set(root: Path, rel_file: str, mode: str, base: str) -> Set[int]:
    """1-based line numbers added/modified on the '+' side of the diff."""
    res = run(["git", "diff", "-U0", *_scope_args(mode, base), "--", rel_file], cwd=root)
    lines: Set[int] = set()
    for line in res.stdout.splitlines():
        m = _HUNK.match(line)
        if not m:
            continue
        start = int(m.group(1))
        count = int(m.group(2)) if m.group(2) is not None else 1
        lines.update(range(start, start + count))
    return lines


# --------------------------------------------------------------------------- #
# tool invocation
# --------------------------------------------------------------------------- #
def _swiftlint_env(root: Path, files: List[str]) -> dict:
    env = os.environ.copy()
    env["SCRIPT_INPUT_FILE_COUNT"] = str(len(files))
    for i, f in enumerate(files):
        env[f"SCRIPT_INPUT_FILE_{i}"] = str(root / f)
    return env


def run_swiftformat(bin_path: Optional[str], root: Path, files: List[str],
                    config: Optional[Path], dry: bool) -> None:
    if not bin_path:
        warn(f"swiftformat ('{SWIFTFORMAT_BIN}') not found — skipping step 1.")
        return
    cmd = [bin_path]
    if config:
        cmd += ["--config", str(config)]
    if dry:
        cmd += ["--dryrun"]
    cmd += [str(root / f) for f in files]
    info(f"SwiftFormat ({'dry-run' if dry else 'fixing'}) {len(files)} file(s)…")
    res = run(cmd, cwd=root)
    out = (res.stdout + res.stderr).strip()
    if out:
        print(out)
    (ok if res.returncode == 0 else warn)("SwiftFormat done.")


def run_swiftlint_fix(bin_path: Optional[str], root: Path, files: List[str],
                      config: Optional[Path], dry: bool) -> None:
    if not bin_path:
        warn(f"swiftlint ('{SWIFTLINT_BIN}') not found — skipping step 2.")
        return
    if dry:
        info("SwiftLint --fix skipped in dry-run.")
        return
    cmd = [bin_path, "--fix", "--use-script-input-files", "--quiet"]
    if config:
        cmd += ["--config", str(config)]
    info(f"SwiftLint --fix on {len(files)} file(s)…")
    res = run(cmd, cwd=root, env=_swiftlint_env(root, files))
    out = (res.stdout + res.stderr).strip()
    if out:
        print(out)
    ok("SwiftLint auto-fix done.")


def lint_violations(bin_path: Optional[str], root: Path, files: List[str],
                    config: Optional[Path]) -> List[dict]:
    if not bin_path or not files:
        return []
    cmd = [bin_path, "lint", "--use-script-input-files", "--reporter", "json", "--quiet"]
    if config:
        cmd += ["--config", str(config)]
    res = run(cmd, cwd=root, env=_swiftlint_env(root, files))
    try:
        return json.loads(res.stdout or "[]")
    except json.JSONDecodeError:
        warn("Could not parse SwiftLint JSON output.")
        if res.stderr.strip():
            print(res.stderr.strip())
        return []


# --------------------------------------------------------------------------- #
# custom fixers — SAFE, mechanical, applied only on lines SwiftLint flagged
# --------------------------------------------------------------------------- #
_IDENT = r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*"   # identifier or simple member chain

def _fix_empty_count(line: str) -> str:
    line = re.sub(rf"({_IDENT})\.count\s*==\s*0", r"\1.isEmpty", line)
    line = re.sub(rf"({_IDENT})\.count\s*<\s*1", r"\1.isEmpty", line)
    line = re.sub(rf"({_IDENT})\.count\s*!=\s*0", r"!\1.isEmpty", line)
    line = re.sub(rf"({_IDENT})\.count\s*>\s*0", r"!\1.isEmpty", line)
    line = re.sub(rf"0\s*==\s*({_IDENT})\.count", r"\1.isEmpty", line)
    return line

def _fix_empty_string(line: str) -> str:
    line = re.sub(rf'({_IDENT})\s*==\s*""', r"\1.isEmpty", line)
    line = re.sub(rf'({_IDENT})\s*!=\s*""', r"!\1.isEmpty", line)
    line = re.sub(rf'""\s*==\s*({_IDENT})', r"\1.isEmpty", line)
    line = re.sub(rf'""\s*!=\s*({_IDENT})', r"!\1.isEmpty", line)
    return line

# rule_id -> single-line transform. Keep short and conservative.
LINE_FIXERS: Dict[str, Callable[[str], str]] = {
    "empty_count": _fix_empty_count,
    "empty_string": _fix_empty_string,
}


def apply_custom_fixers(root: Path, rel_file: str, violations: List[dict],
                        allowed_lines: Optional[Set[int]], dry: bool) -> int:
    targets = [
        (v["line"], v["rule_id"]) for v in violations
        if v.get("rule_id") in LINE_FIXERS and isinstance(v.get("line"), int)
    ]
    if not targets:
        return 0
    path = root / rel_file
    lines = path.read_text().splitlines(keepends=True)
    changed = 0
    for ln, rule in targets:
        if allowed_lines is not None and ln not in allowed_lines:
            continue
        idx = ln - 1
        if not (0 <= idx < len(lines)):
            continue
        new = LINE_FIXERS[rule](lines[idx])
        if new != lines[idx]:
            lines[idx] = new
            changed += 1
    if changed and not dry:
        path.write_text("".join(lines))
    return changed


# --------------------------------------------------------------------------- #
# reporting
# --------------------------------------------------------------------------- #
def report(violations_by_file: Dict[str, List[dict]]) -> int:
    total = sum(len(v) for v in violations_by_file.values())
    if total == 0:
        ok("No remaining violations in scope. 🎉")
        return 0
    warn(f"{total} violation(s) need manual attention:\n")
    by_rule: Dict[str, List[str]] = {}
    for rel, vs in violations_by_file.items():
        for v in vs:
            loc = f"{rel}:{v.get('line', '?')}:{v.get('character') or ''}".rstrip(':')
            sev = (v.get("severity") or "warning").lower()
            tag = _c("31" if sev == "error" else "33", sev[0].upper())
            by_rule.setdefault(v.get("rule_id", "unknown"), []).append(
                f"   [{tag}] {loc}  {v.get('reason', '').strip()}"
            )
    for rule in sorted(by_rule):
        print(_c("1", f"  {rule}  ({len(by_rule[rule])})"))
        for entry in by_rule[rule]:
            print(entry)
        print()
    return total


# --------------------------------------------------------------------------- #
# config resolution
# --------------------------------------------------------------------------- #
def resolve_config(explicit: str, cfg_dir: Path, name: str) -> Optional[Path]:
    if explicit:
        p = Path(explicit).expanduser()
        if not p.is_file():
            warn(f"Configured rules file not found: {p}")
            return None
        return p
    p = cfg_dir / name
    return p if p.is_file() else None


# --------------------------------------------------------------------------- #
# optional aggressive-fixer module (loaded only with --aggressive)
# --------------------------------------------------------------------------- #
def load_aggressive_module():
    cand = Path(__file__).resolve().parent / "swift_fix_aggressive.py"
    if not cand.is_file():
        return None
    spec = importlib.util.spec_from_file_location("swift_fix_aggressive", cand)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("repo", help="Local path to a git checkout, or a clone URL.")
    ap.add_argument("--branch", help="Branch to checkout (local) or clone (URL).")
    ap.add_argument("--mode", choices=["working", "staged", "branch"], default="working",
                    help="working=all changes vs HEAD (default); staged=index only; "
                         "branch=diff vs --base. Note: a fresh URL clone has no "
                         "working diff — use --mode branch for those.")
    ap.add_argument("--base", default="origin/main",
                    help="Base ref for --mode branch (default origin/main).")
    ap.add_argument("--config-dir", default=".",
                    help="Folder (relative to repo root) to auto-discover rules files "
                         "when SWIFTLINT_CONFIG / SWIFTFORMAT_CONFIG are blank.")
    ap.add_argument("--diff-only", action="store_true",
                    help="Restrict custom fixers AND the report to changed lines only.")
    ap.add_argument("--dry-run", action="store_true", help="Preview; write nothing.")
    ap.add_argument("--aggressive", action="store_true",
                    help="EXPERIMENTAL: also run swift_fix_aggressive.py for semantic "
                         "rewrites (first_where, contains_over_filter_count, etc.). "
                         "Review the diff carefully.")
    ap.add_argument("--fatal-error-message", default="TODO: provide a failure reason",
                    help="Placeholder inserted into empty fatalError() by --aggressive.")
    ap.add_argument("--no-fail", action="store_true",
                    help="Exit 0 even if manual violations remain.")
    ap.add_argument("--cleanup", action="store_true",
                    help="Delete the temp clone on exit (URL repos only).")
    args = ap.parse_args()

    # resolve tool binaries from the top-of-file config
    sl_bin = shutil.which(SWIFTLINT_BIN)
    sf_bin = shutil.which(SWIFTFORMAT_BIN)

    root, cloned = prepare_repo(args.repo, args.branch)
    try:
        cfg_dir = (root / args.config_dir).resolve()
        sl_cfg = resolve_config(SWIFTLINT_CONFIG, cfg_dir, ".swiftlint.yml")
        sf_cfg = resolve_config(SWIFTFORMAT_CONFIG, cfg_dir, ".swiftformat")

        if cloned and args.mode == "working":
            warn("Fresh clone has no working-tree diff; consider --mode branch --base <ref>.")

        files = changed_swift_files(root, args.mode, args.base)
        if not files:
            ok("No changed .swift files in scope. Nothing to do.")
            return 0
        info(f"{len(files)} changed Swift file(s) in scope ({args.mode}).")

        # 1 & 2 — auto-fixers own all formatting + correctable lint rules.
        run_swiftformat(sf_bin, root, files, sf_cfg, args.dry_run)
        run_swiftlint_fix(sl_bin, root, files, sl_cfg, args.dry_run)

        # 3 — safe custom rewrites on flagged lines only.
        pre = lint_violations(sl_bin, root, files, sl_cfg)
        pre_by_file: Dict[str, List[dict]] = {}
        for v in pre:
            rel = os.path.relpath(v["file"], root) if os.path.isabs(v["file"]) else v["file"]
            pre_by_file.setdefault(rel, []).append(v)

        fixed = 0
        for rel in files:
            allowed = changed_line_set(root, rel, args.mode, args.base) if args.diff_only else None
            fixed += apply_custom_fixers(root, rel, pre_by_file.get(rel, []), allowed, args.dry_run)
        if fixed:
            ok(f"Custom fixers rewrote {fixed} line(s) "
               f"({'preview only' if args.dry_run else 'applied'}). Review the diff.")

        # 3b — EXPERIMENTAL aggressive semantic fixers (opt-in).
        if args.aggressive:
            agg = load_aggressive_module()
            if agg is None:
                warn("swift_fix_aggressive.py not found beside this script — "
                     "skipping --aggressive.")
            else:
                warn("Running EXPERIMENTAL aggressive fixers — review the diff carefully.")
                mid = lint_violations(sl_bin, root, files, sl_cfg)
                if args.diff_only:
                    mid = [
                        v for v in mid
                        if v.get("line") in changed_line_set(
                            root,
                            os.path.relpath(v["file"], root) if os.path.isabs(v["file"]) else v["file"],
                            args.mode, args.base)
                    ]
                summary = agg.run_aggressive_fixers(
                    root, mid, dry=args.dry_run,
                    fatal_message=args.fatal_error_message)
                if summary["changed"]:
                    ok(f"Aggressive fixers rewrote {summary['changed']} line(s) "
                       f"across {len(summary['files'])} file(s).")
                for rid, count in summary.get("report_only", {}).items():
                    hint = ("use SwiftFormat --wraparguments/--wrapparameters"
                            if rid.startswith("multiline") else "rewrite by hand")
                    warn(f"{rid}: {count} case(s) NOT auto-fixed — {hint}.")

        # 4 — re-lint and report the residue.
        final = lint_violations(sl_bin, root, files, sl_cfg)
        final_by_file: Dict[str, List[dict]] = {}
        for v in final:
            rel = os.path.relpath(v["file"], root) if os.path.isabs(v["file"]) else v["file"]
            if args.diff_only and v.get("line") not in changed_line_set(root, rel, args.mode, args.base):
                continue
            final_by_file.setdefault(rel, []).append(v)

        remaining = report(final_by_file)
        return 1 if (remaining and not args.no_fail) else 0
    finally:
        if cloned and args.cleanup:
            shutil.rmtree(root, ignore_errors=True)
            info(f"Removed temp clone {root}")
        elif cloned:
            info(f"Temp clone left at {root}")


if __name__ == "__main__":
    sys.exit(main())
