#!/usr/bin/env python3
"""
swift_fix_aggressive.py — EXPERIMENTAL semantic SwiftLint auto-fixes.

Invoked by swift_fix.py when --aggressive is passed, or runnable standalone.
Only SINGLE-LINE, unambiguous cases are rewritten; anything multi-line, nested,
or string-interpolated is skipped (left for the human), never guessed at.

  first_where                 .filter { … }.first       -> .first(where: { … })
  last_where                  .filter { … }.last        -> .last(where: { … })
  contains_over_filter_count  .filter { … }.count > 0   -> .contains(where: { … })
                              (only > 0 / != 0 / >= 1 ; == 0 / < 1 are reported)
  fatal_error_message         fatalError()              -> fatalError("<message>")
  reduce_into                 REPORT-ONLY  (semantic rewrite — not mechanizable)
  multiline_arguments         REPORT-ONLY  (use SwiftFormat --wraparguments)
  multiline_parameters        REPORT-ONLY  (use SwiftFormat --wrapparameters)

These transforms are mechanical, not parser-backed. ALWAYS review the diff.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

HANDLED = {
    "first_where", "last_where", "contains_over_filter_count",
    "fatal_error_message", "reduce_into",
    "multiline_arguments", "multiline_parameters",
}
REPORT_ONLY = {"reduce_into", "multiline_arguments", "multiline_parameters"}

# Positive comparisons that need NO leading '!' (safe). Negated ones are skipped
# because the '!' would have to be placed before the receiver expression, which
# we cannot locate reliably without a parser.
_POSITIVE_CMP = {(">", 0), ("!=", 0), (">=", 1)}
_COUNT_CMP = re.compile(r"\s*\.count\s*(==|!=|>=|<=|>|<)\s*(\d+)")


# --------------------------------------------------------------------------- #
# console helpers
# --------------------------------------------------------------------------- #
def _c(code: str, s: str) -> str:
    return f"\033[{code}m{s}\033[0m" if sys.stdout.isatty() else s

def info(s: str) -> None: print(_c("36", "» ") + s)
def ok(s: str) -> None:   print(_c("32", "✓ ") + s)
def warn(s: str) -> None: print(_c("33", "! ") + s)


# --------------------------------------------------------------------------- #
# balanced single-line scanner (respects "…" strings; bails on multi-line)
# --------------------------------------------------------------------------- #
def _scan_balanced(s: str, start: int, op: str, cl: str) -> Optional[int]:
    """s[start] == op. Returns index just past the matching close, or None
    if it doesn't balance within this line."""
    depth = 0
    in_str = False
    i = start
    n = len(s)
    while i < n:
        c = s[i]
        if in_str:
            if c == "\\":
                i += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
        elif c == op:
            depth += 1
        elif c == cl:
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return None


def _too_complex(fragment: str) -> bool:
    """Bail on string interpolation or multiline-string markers — our naive
    string handling can't track those safely."""
    return '"""' in fragment or "\\(" in fragment


def _parse_filter_arg(line: str, after_filter: int) -> Optional[Tuple[str, int]]:
    """Given index just past 'filter', return (closure_with_braces, end_index)
    when the argument is a single-line brace closure; else None."""
    j = after_filter
    while j < len(line) and line[j] == " ":
        j += 1
    if j >= len(line):
        return None
    if line[j] == "{":
        end = _scan_balanced(line, j, "{", "}")
        if end is None:
            return None
        frag = line[j:end]
        if _too_complex(frag):
            return None
        return frag, end
    if line[j] == "(":
        end = _scan_balanced(line, j, "(", ")")
        if end is None:
            return None
        inner = line[j + 1:end - 1].strip()
        if inner.startswith("{") and inner.endswith("}") and not _too_complex(inner):
            return inner, end
        return None  # function reference or odd form — skip
    return None


def _boundary(line: str, idx: int) -> bool:
    """True if char at idx is not an identifier char (so '.first' isn't part
    of '.firstIndex')."""
    if idx >= len(line):
        return True
    c = line[idx]
    return not (c.isalnum() or c == "_")


# --------------------------------------------------------------------------- #
# line transforms
# --------------------------------------------------------------------------- #
def _apply_first_last(line: str, method: str) -> str:
    out = line
    pos = 0
    while True:
        m = out.find(".filter", pos)
        if m == -1:
            return out
        parsed = _parse_filter_arg(out, m + len(".filter"))
        if not parsed:
            pos = m + len(".filter")
            continue
        closure, end = parsed
        k = end
        while k < len(out) and out[k] == " ":
            k += 1
        suffix = "." + method
        if out[k:k + len(suffix)] == suffix and _boundary(out, k + len(suffix)):
            repl = f".{method}(where: {closure})"
            out = out[:m] + repl + out[k + len(suffix):]
            pos = m + len(repl)
        else:
            pos = m + len(".filter")


def _apply_contains_count(line: str) -> str:
    out = line
    pos = 0
    while True:
        m = out.find(".filter", pos)
        if m == -1:
            return out
        parsed = _parse_filter_arg(out, m + len(".filter"))
        if not parsed:
            pos = m + len(".filter")
            continue
        closure, end = parsed
        cm = _COUNT_CMP.match(out, end)
        if not cm:
            pos = m + len(".filter")
            continue
        op, num = cm.group(1), int(cm.group(2))
        if (op, num) not in _POSITIVE_CMP:  # negated case -> leave for manual fix
            pos = m + len(".filter")
            continue
        repl = f".contains(where: {closure})"
        out = out[:m] + repl + out[cm.end():]
        pos = m + len(repl)


def _apply_fatal(line: str, message: str) -> str:
    safe = message.replace("\\", "\\\\").replace('"', '\\"')
    return re.sub(r"\bfatalError\(\s*\)", f'fatalError("{safe}")', line)


# --------------------------------------------------------------------------- #
# public entry point (called by swift_fix.py)
# --------------------------------------------------------------------------- #
def run_aggressive_fixers(root: Path, violations: List[dict], *, dry: bool = False,
                          fatal_message: str = "TODO: provide a failure reason") -> dict:
    by_file: Dict[str, Dict[str, Set[int]]] = {}
    for v in violations:
        rid = v.get("rule_id")
        if rid not in HANDLED:
            continue
        by_file.setdefault(v["file"], {}).setdefault(rid, set()).add(v.get("line"))

    summary = {"changed": 0, "files": set(), "report_only": {}}
    for f, rules in by_file.items():
        path = Path(f) if os.path.isabs(f) else (root / f)
        if not path.is_file():
            continue
        lines = path.read_text().splitlines(keepends=True)
        file_changed = 0
        for rid, lns in rules.items():
            if rid in REPORT_ONLY:
                summary["report_only"][rid] = summary["report_only"].get(rid, 0) + len(lns)
                continue
            for ln in lns:
                if not isinstance(ln, int):
                    continue
                idx = ln - 1
                if not (0 <= idx < len(lines)):
                    continue
                orig = lines[idx]
                if rid == "first_where":
                    new = _apply_first_last(orig, "first")
                elif rid == "last_where":
                    new = _apply_first_last(orig, "last")
                elif rid == "contains_over_filter_count":
                    new = _apply_contains_count(orig)
                elif rid == "fatal_error_message":
                    new = _apply_fatal(orig, fatal_message)
                else:
                    continue
                if new != orig:
                    lines[idx] = new
                    file_changed += 1
        if file_changed:
            summary["changed"] += file_changed
            summary["files"].add(str(path))
            if not dry:
                path.write_text("".join(lines))
    return summary


# --------------------------------------------------------------------------- #
# standalone CLI (re-lints the given files itself)
# --------------------------------------------------------------------------- #
def _lint(bin_path: str, root: Path, files: List[str], config: Optional[str]) -> List[dict]:
    env = os.environ.copy()
    env["SCRIPT_INPUT_FILE_COUNT"] = str(len(files))
    for i, f in enumerate(files):
        env[f"SCRIPT_INPUT_FILE_{i}"] = str((root / f))
    cmd = [bin_path, "lint", "--use-script-input-files", "--reporter", "json", "--quiet"]
    if config:
        cmd += ["--config", config]
    res = subprocess.run(cmd, cwd=str(root), env=env, capture_output=True, text=True)
    try:
        return json.loads(res.stdout or "[]")
    except json.JSONDecodeError:
        return []


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("repo", help="Path to the git checkout root.")
    ap.add_argument("--files", nargs="+", required=True,
                    help="Swift files (relative to repo root) to process.")
    ap.add_argument("--swiftlint-bin", default="swiftlint")
    ap.add_argument("--config", default=None, help="Path to .swiftlint.yml.")
    ap.add_argument("--fatal-error-message", default="TODO: provide a failure reason")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    root = Path(args.repo).expanduser().resolve()
    bin_path = shutil.which(args.swiftlint_bin)
    if not bin_path:
        warn(f"swiftlint ('{args.swiftlint_bin}') not found; cannot detect violations.")
        return 2

    warn("EXPERIMENTAL aggressive fixers — review the resulting diff carefully.")
    violations = _lint(bin_path, root, args.files, args.config)
    summary = run_aggressive_fixers(root, violations, dry=args.dry_run,
                                    fatal_message=args.fatal_error_message)
    if summary["changed"]:
        ok(f"Rewrote {summary['changed']} line(s) across "
           f"{len(summary['files'])} file(s) "
           f"({'preview only' if args.dry_run else 'applied'}).")
    else:
        ok("No single-line aggressive fixes applied.")
    for rid, count in summary["report_only"].items():
        hint = ("use SwiftFormat --wraparguments/--wrapparameters"
                if rid.startswith("multiline") else "rewrite by hand")
        warn(f"{rid}: {count} case(s) NOT auto-fixed — {hint}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
